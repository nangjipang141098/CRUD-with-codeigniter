-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Jul 2019 pada 13.26
-- Versi server: 10.1.34-MariaDB
-- Versi PHP: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pabrik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bagian`
--

CREATE TABLE `bagian` (
  `kode_bagian` bigint(15) NOT NULL,
  `nama_bagian` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bagian`
--

INSERT INTO `bagian` (`kode_bagian`, `nama_bagian`) VALUES
(1, 'CEO'),
(2, 'MANAGER'),
(3, 'STAFF'),
(4, 'OPERATOR');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gaji`
--

CREATE TABLE `gaji` (
  `kode_bagian` bigint(15) NOT NULL,
  `jumlah` bigint(15) DEFAULT NULL,
  `pajak` float DEFAULT NULL,
  `jumlah_pajak` bigint(20) DEFAULT NULL,
  `jumlah_gaji` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gaji`
--

INSERT INTO `gaji` (`kode_bagian`, `jumlah`, `pajak`, `jumlah_pajak`, `jumlah_gaji`) VALUES
(1, 20000000, 0.2, 4000000, 16000000),
(2, 10000000, 0.17, 1700000, 8300000),
(3, 7000000, 0.15, 1050000, 5950000),
(4, 4000000, 0.1, 400000, 3600000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `nama` varchar(50) DEFAULT NULL,
  `kode_bagian` bigint(15) NOT NULL DEFAULT '0',
  `jenis_kelamin` enum('LAKI-LAKI','PEREMPUAN') DEFAULT NULL,
  `id_karyawan` bigint(15) NOT NULL DEFAULT '0',
  `alamat` varchar(60) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`nama`, `kode_bagian`, `jenis_kelamin`, `id_karyawan`, `alamat`, `password`) VALUES
('Danang Aji Pangestu', 1, 'LAKI-LAKI', 173112706450221, 'Bekasi', '$2y$10$3bm.gZ.hH5KfxgjmtuaeXupbLA3uVz7DTzrhD1isc0AXWQ8uwfYL.'),
('AJI PANGESTU', 1, 'LAKI-LAKI', 173112706450228, 'TAMBUN', '$2y$10$tladNO4Vti8p/FDhm3IdaugZjp3qRFMGkj7Wh4ssIB4JEbrx4wzCG');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bagian`
--
ALTER TABLE `bagian`
  ADD PRIMARY KEY (`kode_bagian`);

--
-- Indeks untuk tabel `gaji`
--
ALTER TABLE `gaji`
  ADD PRIMARY KEY (`kode_bagian`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`kode_bagian`,`id_karyawan`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `gaji`
--
ALTER TABLE `gaji`
  ADD CONSTRAINT `gaji_ibfk_1` FOREIGN KEY (`kode_bagian`) REFERENCES `bagian` (`kode_bagian`);

--
-- Ketidakleluasaan untuk tabel `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`kode_bagian`) REFERENCES `bagian` (`kode_bagian`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
