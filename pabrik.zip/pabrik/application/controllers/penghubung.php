<?php

class Penghubung extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('UserModel');
    $this->load->library('session');
  }

  public function login(){
    $username = $this->input->post('username');
    $password = $this->input->post('password');
        $cek_query_insert=$this->UserModel->login_user($username);     
        $data=$cek_query_insert->row_array();
        if(password_verify($password, $data['password'])){
            $this->session->set_userdata('id_karyawan', $data['id_karyawan']);
            $this->session->set_userdata('password', $data['password']);
            $this->session->set_userdata('nama', $data['nama']);
            $this->load->view('menu.php');
                  
            $this->input->set_cookie('id', $username, 450);
            $this->input->set_cookie('Nama', $data['nama'], 450);      
        }        
        else{  
            echo "<script>alert('data yang anda insert salah, pastikan lagi')</script>";
            return $this->load->view('login.php');
        }       
  }

  public function daftar(){
    $this->load->view('daftar.php');
  }

  public function proses_daftar(){
      $nama = $this->input->post('nama');
      $kode_bagian = $this->input->post('kode_bagian');
      $jenis_kelamin = $this->input->post('jenis_kelamin');
      $id = $this->input->post('id_karyawan');
      $alamat = $this->input->post('alamat');
      $password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);

      $cek_query_insert=$this->UserModel->login_user($id);
      $cek_data=$cek_query_insert->num_rows();
      if($cek_data>0){
          echo "<script>alert('id karywan sudah ada')</script>";
          return $this->load->view('login.php');
      }
      else{
          $daftar_user=$this->UserModel->daftar_user($nama,$kode_bagian,$jenis_kelamin,$id,$alamat,$password);
          $this->load->view('login.php');
      }
  }

  public function utama(){
    $this->load->view('login.php');
  }

  public function view(){
		$data['user'] = $this->UserModel->tampil_data();
		$this->load->view('menu',$data);
	}


}