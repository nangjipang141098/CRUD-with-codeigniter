<h1>Selamat datang <?php echo $this->session->userdata('nama'); ?></h1><td>
<a href="utama"> LOGOUT </a><br>
<a href="daftar"> TAMBAHKAN USER </a><br>
<br><h1>Berikut daftar anggota </h1>

<?php
$cek_query=$this->UserModel->lihat_user(); 
foreach ($cek_query->result_array() as $row)
{
        echo "|| " . $row['nama'] . " ||" .  $row['jenis_kelamin'] . " ||" .  $row['alamat'] . "<br>" ; 
}
?>
<td>