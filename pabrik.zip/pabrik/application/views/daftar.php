<html>
<center><head> SILAHKAN DAFTAR DAFTAR </head></center>
    <form method="post" action="<?php echo base_url('index.php/penghubung/proses_daftar') ?>">
    <body>
        <table border="3" align="center">
            <tr>
                <td> NAMA </td> 
                <td>:</td> 
                <td> <input type="text" name="nama" size="45"> </td>
            </tr>
            <tr>
                <td> BAGIAN </td>
                <td>:</td>
                <td><select name="kode_bagian">
                    <option value="1"> CEO </option>
                    <option value="2"> MANAGER </option>
                    <option value="3"> STAF </option>
                    <option value="4"> OPERATOR </option>
                </select></td>
            </tr>
            <tr>
                <td> JENIS KELAMIN </td>
                <td> : </td>
                <td>
                    <input type="radio" name="jenis_kelamin" value="LAKI-LAKI" checked> LAKI-LAKI 
                    <input type="radio" name="jenis_kelamin" value="PEREMPUAN"> PEREMPUAN </td>
                </tr>
            <tr>
                <td> ID KARYAWAN </td>
                <td>:</td>
                <td><input type="text" name="id_karyawan" size="45"> </td>
            </tr>
            <tr>
                <td> ALAMAT </td> 
                <td>:</td> 
                <td><input type="text" name="alamat" size="45"></td>
            </tr>
            <tr>
                <td> PASSWORD </td> 
                <td>:</td> 
                <td><input type="text" name="password" size="45"></td>
            </tr>
            <tr>
                <td>
                    <button type="submit">daftar</button>
                </td>
            </tr>
</table>
</body>
<form>
</html>

