<?php 
class UserModel extends CI_Model {
    
    function login_user($username){       
        $query=$this->db->query("select * from user where id_karyawan='$username'");
        return $query;
    }
    function daftar_user($nama,$kode_bagian,$jenis_kelamin,$id,$alamat,$password){
        $query=$this->db->query("INSERT INTO user (nama, kode_bagian, jenis_kelamin, id_karyawan, alamat, password) 
        values ('$nama','$kode_bagian','$jenis_kelamin','$id','$alamat','$password')");
        return $query;     
    }
    function lihat_user(){       
        $query=$this->db->query("select * from user");
        return $query;
    }
    
}