<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aksi extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('UserModel');
		$this->load->library('session');
	  }

	public function hapus(){
		$ni = $this->input->get('ni');
	
		$cek_query_insert=$this->UserModel->hapus_user($ni);
		return $this->load->view('menu.php');
	}
	
	public function utama(){
		$this->load->view('login.php');
	}

	public function edit(){
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$alamat = $this->input->post('alamat');
		$jenis_kelamin = $this->input->post('jenis_kelamin');	
		$semester = $this->input->post('semester');
		$hobi = implode($this->input->post('hobi'), ', ');
		$keterangan = $this->input->post('keterangan');

		$cek_query_insert=$this->UserModel->edit_user($nim, $nama, $alamat, $jenis_kelamin, $semester, $hobi, $keterangan);
		return $this->load->view('menu.php');
	}
}
