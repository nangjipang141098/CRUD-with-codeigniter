<?php

class Penghubung extends CI_Controller {
  public function __construct(){
    parent::__construct();
    $this->load->model('UserModel');
    $this->load->library('session');
    $this->load->library('form_validation');
  }

  public function login(){
    $username = $this->input->post('username');
    $password = $this->input->post('password');
        $cek_query_insert=$this->UserModel->login_user($username);     
        $data=$cek_query_insert->row_array();
        if(password_verify($password, $data['password'])){
            $this->session->set_userdata('nim', $data['nim']);
            $this->session->set_userdata('password', $data['password']);
            $this->session->set_userdata('nama', $data['nama']);
            $this->load->view('menu.php');
                  
            $this->input->set_cookie('id', $username, 450);
            $this->input->set_cookie('Nama', $data['nama'], 450);      
        }        
        else{  
            echo "<script>alert('data yang anda insert salah, pastikan lagi')</script>";
            return $this->load->view('login.php');
        }       
  }

  public function vdaftar(){
    $this->load->view('daftar.php');
  }

  public function vlogin(){
    $this->load->view('login.php');
  }


  public function proses_daftar(){
		$nim = $this->input->post('nim');
		$nama = $this->input->post('nama');
		$alamat = $this->input->post('alamat');
		$jenis_kelamin = $this->input->post('jenis_kelamin');	
		$semester = $this->input->post('semester');
		$hobi = implode($this->input->post('hobi'), ', ');
		$keterangan = $this->input->post('keterangan');
		$password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
    
    
    
    $cek_query_insert=$this->UserModel->login_user($nim);
    
		$cek_data=$cek_query_insert->num_rows();
		if($cek_data>0){
      foreach ($cek_query_insert->result_array() as $row)
      {  
        echo "<script>alert('Nim ".$row['nim']." sudah digunakan ".$row['nama']."')</script>";       
        
      }	
			return $this->load->view('home.php');
		}
		else{
			$daftar_user=$this->UserModel->daftar_user($nim, $nama, $alamat, $jenis_kelamin, $semester, $hobi, $keterangan, $password);
			return $this->load->view('home.php');
		}
	}

  public function utama(){
    $this->load->view('home.php');
  }

  public function vedit(){
    $this->load->view('edit.php');
  }
  

}