<?php 
class UserModel extends CI_Model {
    
    function login_user($username){       
        $query=$this->db->query("select * from mahasiswa where nim='$username'");
        return $query;
    }

    public function daftar_user($nim, $nama, $alamat, $jenis_kelamin, $semester, $hobi, $keterangan, $password){
        $query = $this->db->query("INSERT INTO mahasiswa(nim, nama, alamat, jenis_kelamin, semester, hobi, keterangan, password) VALUES ('$nim','$nama','$alamat','$jenis_kelamin','$semester','$hobi','$keterangan', '$password' ) ");
        return $query;
    }

    public function lihat_user(){
        $query=$this->db->query("select * from mahasiswa");
        return $query;
    }

    public function hapus_user($nim){
        $query=$this->db->query("DELETE FROM mahasiswa WHERE nim = '$nim'");
        return $query;
    }

    public function get_edit($username){       
        $query=$this->db->query("select * from mahasiswa where nim='$username'");
        return $query;
    }

    public function edit_user($nim, $nama, $alamat, $jenis_kelamin, $semester, $hobi, $keterangan){
        $query=$this->db->query("UPDATE mahasiswa SET nama='$nama', alamat='$alamat', jenis_kelamin='$jenis_kelamin', semester='$semester', hobi='$hobi', keterangan='$keterangan' WHERE nim = '$nim'");
        return $query;
    }
    
    
}