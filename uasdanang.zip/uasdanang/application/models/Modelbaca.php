<?php
    class Modelbaca extends ci_model{
        public function tampil_data(){
            return $this->db->get('mahasiswa');
        }
    }
?>