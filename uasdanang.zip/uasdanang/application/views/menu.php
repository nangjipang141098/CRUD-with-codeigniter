<h1>Selamat datang <?php echo $this->session->userdata('nama'); ?></h1><td>

<br><h1 align="center">Berikut Daftar Anggota </h1>
<table border="3" align="center">
        <tr> 
                <td>NIM</td>
                <td>Nama</td>
                <td>Alamat</td>
                <td>Jenis Kelamin</td>
                <td>Hobbi</td>
                <td>Keterangan</td>
                <td>Aksi</td>
        <tr>

        <?php
        $cek_query=$this->UserModel->lihat_user(); 
        foreach ($cek_query->result_array() as $row)
        {       
        ?>
        <tr>
                <td><?php echo $row['nim'] ; ?></td>
                <td><?php echo $row['nama']; ?></td>
                <td><?php echo $row['alamat'] ;?></td>
                <td><?php echo $row['jenis_kelamin'] ; ?></td>
                <td><?php echo $row['hobi']; ?></td>
                <td><?php echo $row['keterangan'] ;?></td>
                <td>
                        <a href="<?php echo base_url('index.php/aksi/hapus?ni=') . $row['nim']; ?>"> Hapus data || </a>         
                        <a href="<?php echo base_url('index.php/penghubung/vedit?ni=') . $row['nim']; ?>"> Ubah data </a>
                </td>
        </tr>
        <?php }?>


</table>

<h3><a href="<?php echo base_url('index.php/penghubung/utama')  ?>"> LOGOUT </a><br>
<a href="<?php echo base_url('index.php/penghubung/vdaftar')  ?>"> TAMBAHKAN USER </a><br></h3>