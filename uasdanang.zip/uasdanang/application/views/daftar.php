<html>
<center><head> SILAHKAN DAFTAR DAFTAR </head></center>
    <form method="post" action="<?php echo base_url('index.php/penghubung/proses_daftar') ?>">
    <body>
        <table border="3" align="center">
        <tr>
                <td> NIM </td> 
                <td>:</td> 
                <td> <input type="number" name="nim" size="45"> </td>
            </tr>
            <tr>
                <td> NAMA </td> 
                <td>:</td> 
                <td> <input type="text" name="nama" size="45"> </td>
            </tr>
            <tr>
                <td> ALAMAT </td> 
                <td>:</td> 
                <td><input type="text" name="alamat" size="45"></td>
            </tr>
            <tr>
                <td> JENIS KELAMIN </td>
                <td> : </td>
                <td>
                    <input type="radio" name="jenis_kelamin" value="L" checked> LAKI-LAKI 
                    <input type="radio" name="jenis_kelamin" value="P"> PEREMPUAN </td>
            </tr>
            <tr>
                <td> SEMESTER </td>
                <td>:</td>
                <td>
                <select name="semester">
                    <option selected="selected"></option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                        <option>6</option>
                        <option>7</option>
                        <option>8</option>
                        <option>9</option>
                </select>
                </td>
            </tr>
            
            <tr>
                <td> HOBBY </td>
                <td>:</td>
                <td> 
                    <p><input type="checkbox" name="hobi[]" value="tidur" /> TIDUR</p>
                    <p><input type="checkbox" name="hobi[]" value="makan" /> MAKAN</p>
                    <p><input type="checkbox" name="hobi[]" value="ngopi" /> NGOPI</p> 
                </td>
            </tr>
            <tr>
                <td> PASSWORD </td> 
                <td>:</td> 
                <td><input type="text" name="password" size="45"></td>
            </tr>
            <tr>
                <td> KETERANGAN </td> 
                <td>:</td> 
                <td><textarea name="keterangan" rows="15"></textarea></td>
            </tr>
            <tr>
                <td>
                    <button type="submit">daftar</button>
                </td>
            </tr>
        </table>
</body>
<form>
</html>

