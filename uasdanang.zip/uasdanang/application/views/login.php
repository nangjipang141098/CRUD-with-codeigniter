<html>
<body>
    <form method="POST"  action="<?php echo base_url('index.php/penghubung/login')  ?>" action="data_pribadi.php">
        <table align="center" border=3>
            <tr>
                <td><a> SILAHKAN LOGIN TERLEBIH DAHULU </a></td>
            </tr>
            <tr>
                <td>USERNAME</td> 
                <td>:</td> 
                <td><input type="text" name="username" placeholder="id karyawan"></td>
            <tr>
            <tr>
                <td>PASSOWORD</td> 
                <td>:</td>
                <td><input type="password" name="password" placeholder="Password"></td>
            <tr>
            <tr>
                <td>SILAHKAN MASUK</td> 
                <td>:</td> 
                <td><input type="submit" name="submit" value="submit"></td>
            <tr>
            

            </table>
</form>
</body>
</html>
