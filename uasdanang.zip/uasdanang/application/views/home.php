<center>
<h3> UJIAN AKHIR SEMESTER PRAKTIKUM PEMROGRAMAN WEB <h3><br>
<a href="<?php echo base_url('index.php/penghubung/vlogin')  ?>"> LOGIN </a><br>
<a href="<?php echo base_url('index.php/penghubung/vdaftar')  ?>"> TAMBAHKAN USER </a><br>

</center>